#pragma once
namespace Hooks {
    void InstallFileHook();
}
