﻿#pragma once
namespace Hooks {
    void InstallFontHook();
}
