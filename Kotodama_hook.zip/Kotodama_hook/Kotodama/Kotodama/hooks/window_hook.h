﻿#pragma once
namespace Hooks {
    void InstallWindowHook();
}
